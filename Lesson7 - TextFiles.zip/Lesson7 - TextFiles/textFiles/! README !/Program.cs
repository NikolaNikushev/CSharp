﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace __README__
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * YES 100% of the excercises could have been made more clearer  with methods
             * Sorry, for not making them into methods and clogging the code :(
             * I did not have enought time to Make ALL of the assigments and think
             * about restructuring into methods :s In the future I'll focus more
             * on methods :3
             * Thanks for reading this ReadMe :)
            */
        }
    }
}
