﻿using System;

class Excercise3PrintDayOfWeek
{
    static void Main()
    {
        Console.WriteLine("Current day is : {0}",DateTime.Today.DayOfWeek);
    }
}
